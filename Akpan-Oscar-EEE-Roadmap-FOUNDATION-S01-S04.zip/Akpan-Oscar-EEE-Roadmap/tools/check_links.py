"""Tests every external link in every page. Run from the project root: python tools/check_links.py"""
import re, os, urllib.request, datetime
urls={}
for r,_,fs in os.walk('.'):
    for f in fs:
        if f.endswith('.html'):
            for u in re.findall(r'href="(https?://[^"]+)"', open(os.path.join(r,f),encoding='utf-8').read()):
                urls.setdefault(u.replace('&amp;','&'),set()).add(os.path.join(r,f))
bad=0
for u in sorted(urls):
    try: c=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"Mozilla/5.0"}),timeout=20).status
    except Exception as e: c=getattr(e,"code",str(e))
    ok=c==200; bad+=not ok; print(("OK  " if ok else "FAIL"),c,u)
print(len(urls),"links,",bad,"need attention. Some sites block scripts: open FAIL links in a browser before changing them.",datetime.date.today())
